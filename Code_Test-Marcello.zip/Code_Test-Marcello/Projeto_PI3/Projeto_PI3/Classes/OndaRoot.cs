﻿using Newtonsoft.Json;


namespace Projeto_PI3.Classes
{
    public class OndaRoot
    {
        [JsonProperty("cidade")]
        public string Cidade { get; set; }

        [JsonProperty("estado")]
        public string Estado { get; set; }

        [JsonProperty("atualizado_em")]
        public string AtualizadoEm { get; set; }

        [JsonProperty("ondas")]
        public List<Onda> Ondas { get; set; }
    }
}
